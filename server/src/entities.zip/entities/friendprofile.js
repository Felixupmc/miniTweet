

const friendprofile = ({friend})  => {
    return (
        <ul>
            <li>{friend.name.first}</li>
        </ul>
    );
};

export default friendprofile;